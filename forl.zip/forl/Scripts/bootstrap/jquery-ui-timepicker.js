; (function ($) {
    $(function () {
        $('.datetimepicker').datetimepicker($.datepicker.regional['pt-BR']);
    });
})(jQuery);
